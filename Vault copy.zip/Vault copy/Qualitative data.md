2025-02-05 16:43

Tags: #Data #Statistics 

# Qualitative data


Qualitative data (kwalitatieve data) is gericht op het begrijpen van meningen en ervaringen. je gebruikt kwalitatieve data dan ook voor andere redenen dan [[Quantitative Data]]
















# Referenties 

[Uitleg](https://www.lean.nl/wat-is-kwantitatieve-en-kwalitatieve-data-green-belt/#:~:text=Kwantitatieve%20data%20is%20numeriek%20en,begrijpen%20van%20meningen%20en%20ervaringen.)
