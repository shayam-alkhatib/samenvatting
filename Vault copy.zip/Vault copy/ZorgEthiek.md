2025-02-20 14:08

Tags: #philosophy 

# ZorgEthiek

zorgethiek draait om zorgzaam zijn voor mensen die van belang voor jou zijn. in zorgethiek zou jij je eigen familie of vrienden vaak boven andere kiezen omdat je een persoonlijke relatie met die genen hebt.




# Referenties 