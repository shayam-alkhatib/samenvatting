2025-03-13 14:16

Tags: #rechten 

# Rechterlijke organisatie

rechterlijke organisatie is het Nederlandse verdeling van 11 [[arrondissementen]], 4 [[ressorten]] en 1 [[Hoge raad]].

je kan bij een rechterlijke organisatie een van de 3 veroordelingen krijgen.

1. vrijspraak
2. ontslag van rechtsvervolging
3. veroordeling van verdachte

De rechterlijke organisatie is verdeelt in 4 sectoren.

1. sector kanon
2. civiel recht
3. straf recht
4. bestuursrecht

Ook heb je in Nederland het [[Openbaar Ministerie]]. in kort vervolgen zij strafbare feiten. en het officier van justitie vertegenwoordigd de OM.





# Referenties 