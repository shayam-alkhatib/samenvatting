2025-03-13 14:45

Tags: #algemeen #rechten #Security 

# Computercriminaliteit III

dit wetgeving dat door ging in 2018 geeft de politie eigenlijk het recht om burgers te hacken en informatie op te doen als ze verdacht worden van een strafbaar feit. zoals kinderporno verspreiden of andere cyber crime zaken. ambtenaren krijgen ook meer rechten om onderzoeken online te kunnen doen. 

veel mensen waren hier tegen omdat je ook soms mensen die niks fout hebben gedaan gaat onderzoeken en dan later achterkomt dat ze niks fout hebben gedaan. je houd de algemene burger dus in het visier.




# Referenties 