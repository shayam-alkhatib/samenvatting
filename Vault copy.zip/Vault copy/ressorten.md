2025-03-13 14:23

Tags: #algemeen #rechten 

# ressorten

een ressort is een Nederland gebied waar een [[gerechtshoven]] over gaat als iemand in hoger beroep gaat gaan ze naar een van deze gerechtshovens. de uitspraak van een gerechtshoven noem je een arrest




# Referenties 