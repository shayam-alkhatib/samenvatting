2025-02-20 12:16

Tags: #philosophy 

# DeugdenEthiek

DeugdenEthiek of "Virtue ethics" bekijkt alles vanuit het perspectief van. "wat zou een deugend "virtues" persoon doen. Als centrale punt bespreekt het "hoe wordt ik gelukkig". Volgens Aristoteles bereik je dit door deugden te ontwikkelen: innerlijke karaktertrekken zoals moed, rechtvaardigheid en wijsheid. een persoon met sterke en goeie kwaliteiten die je kan tonen aan anderen.

Geluk betekent voor Aristotle om een leven te leven door deugden te ontwikkelen die voor de samenleving van belang zijn. hierbij gaf hij aan dat de juiste deugden het middel punt is tussen twee extremen.




# Referenties 