2025-03-27 14:43

Tags: #Data 

# Tuple

Een [[Lineaire Datastructuren]] (structuur) die data opslaat. dit zijn de kenmerken van een Tuple:

1. Rij gegevens die in een bepaalde volgorde opgeslagen worden.
2. Waar en hoe in het geheugen opgeslagen is niet relevant.
3. Aantal elementen (gegevens) ligt vast.
4. Gegevens hoeven niet altijd van hetzelfde type te zijn (afhankelijk van de programmeertaal).
5. In Python kunnen gegevens in een tuple niet aangepast of vervangen worden.
6. Indexgebruik is hetzelfde als bij het [[array]].





# Referenties 