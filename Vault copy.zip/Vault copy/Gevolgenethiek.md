2025-02-20 13:35

Tags: #philosophy 

# Gevolgenethiek


Gevolgenethiek ook wel [[consequentialism]] genoemd is een ethische stroming waarbij de uitkomst van een actie de belangrijkste ethische overweging is. Dit geldt ongeacht de [[Normen]] van een samenleving op het moment dat de actie ondernomen wordt. [[Normen]] kunnen wel worden meegenomen om een keuze te maken vooral als de normen zorgen voor betere uitkomsten.

Het tegenovergestelde van Gevolgenethiek is dan ook [[PlichtenEthiek]], waarbij morele principes en plichten centraal staan. Deze benadering is gebaseerd op universele principes, ongeacht de uitkomst van de actie.





# Referenties 