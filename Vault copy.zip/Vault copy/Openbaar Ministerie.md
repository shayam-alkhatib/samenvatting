2025-03-13 14:29

Tags: #algemeen #rechten 

# Openbaar Ministerie

Het openbaar ministerie of (OM) is een nederlandse rechts instantie die strafbare feiten opspoort en vervolgt. de OM wordt ook de aanklager van de staat genoemd.

dit doet de OM
- **Opsporen van strafbare feiten** (samen met de politie).
- **Beslissen of iemand vervolgd wordt** of de zaak wordt geseponeerd (gesloten zonder straf).
- **Eisen van straffen bij de rechter** (zoals boetes, celstraffen of taakstraffen).
- **Uitvoeren van straffen** (zoals het innen van boetes of toezicht houden op taakstraffen).

bij het om hoort ook de officier van justitie. die leiden onderzoeken en beslissen of iemand strafbaar is of voor de rechter moet.


# Referenties 