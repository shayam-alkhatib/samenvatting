2025-02-20 11:11

Tags: #philosophy 

# Ethiek

Ethiek is de leer van wat ethisch of moreel is. ook wel de reflectie van een persoons [[Moraal]]. 

Het wordt gebruikt als Analytische methode om bepaalde dilemma's te beantwoorden en zo op logische en kloppende antwoorden te komen.





# Referenties 