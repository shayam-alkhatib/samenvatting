2025-03-27 14:27

Tags: #Data #algemeen 

# Array

een Array is een [[Lineaire Datastructuren]] dat de volgende kenmerken heeft.

1. het is een Een rij gegevens die achter elkaar in het geheugen worden opgeslagen.
2. Aantal elementen (gegevens) ligt vast.
3. Alle gegevens zijn van hetzelfde type (bijv. integer).
4. Volgordenummer (index) geeft direct toegang tot een bepaald gegeven, zonder dat eerst andere gegevens bekeken moeten worden.

![[Pasted image 20250327142857.png]]

voorbeeld array



# Referenties 