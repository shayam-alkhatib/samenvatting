2025-02-16 11:40

Tags: #Analytics #ICT #Security 

# SCOT

Scot pass je toe op je project/opdracht wanneer je meer inzicht wilt op een bedrijf hun stakeholders problemen en mogelijke oplossingen.

Er zijn 3 voorwaarden om SCOT toe te passen.
1. Relevant social groups. (er moeten relevante sociale groepen zijn)
2. Design flexibility. (De oplossing voor het probleem moet niet simple zijn dus er is niet alleen een oplossing voor het probleem) 
3. Problems and Conflicts. (er moeten problemen zijn die opgelost kunnen worden)

je hebt ook 3 fasen van SCOT
1. Interpretatieve flexibilty
2. Momentum
3. Closure

je moet het zien als een bol met lijnen die steeds rechter wordt na maten je een meer volledig oplossing uitvind. Closure betekent dat er een oplossing is, hierdoor verdwijnt de vraag naar alternatieve oplossingen.

closure is geen permanente conditie dus dit betekent dat het altijd verder opgelost kan worden in de toekomst als iets nieuws aan bod komt.


# Referenties 