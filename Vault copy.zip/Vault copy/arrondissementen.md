2025-03-13 14:17

Tags: #algemeen #rechten 

# arrondissementen

een arrondissement is eigenlijk een rechtbank waar je naartoe gaat als je een rechts uitspraak hebt of iemand aanklaagt. als je hierna een conclusie hebt gekregen kun je in hoger beroep gaan. een uitspraak op arrondissement/rechtbank niveau noem je een vonnis.

als je met een uitspraak niet eens bent kun je in hoger beroep gaan. dan ga je naar een [[gerechtshoven]] 




# Referenties 