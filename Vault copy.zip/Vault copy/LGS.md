2025-02-27 12:19

Tags: #Data #ICT #Analytics 

# LGS

Een LGS in data is simple weg de entiteit type van een database met al zijn waarden erin. dus bijvoorbeeld:

LGS

DOCENT ( PK:docentcode(moet een streep onder), titulatuur, voornaam, tussenvoegsels, achternaam, geboortedatum, … ) 

ROOSTER ( docentcode, klascode, vakcode, jaar, dag, uur, … )

KLAS ( klascode, jaar, studierichting, maxklasgrootte, … )

STUDENT (studentnummer, klascode, voornaam, tussenvoegsels, achternaam, geb.datum, … )


Het is eigenlijk een makkelijke overzicht van je database en de entiteiten die erin zitten.



# Referenties 