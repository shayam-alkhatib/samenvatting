2025-02-05 16:41

Tags: #Data #Statistics 

# Quantitative Data


kwantitatieve data of "Quantitative data" is numerieke data dat geschikt is voor statistische analyse. Het omgekeerde van quantitative data is [[Qualitative data]] of kwalitatieve data.












# Referenties 

[verder uitleg](https://www.lean.nl/wat-is-kwantitatieve-en-kwalitatieve-data-green-belt/#:~:text=Kwantitatieve%20data%20is%20numeriek%20en,begrijpen%20van%20meningen%20en%20ervaringen.)
