2025-03-13 14:25

Tags: #algemeen #rechten 

# Hoge raad

het hoge raad is de laatste stap dat iemand kan nemen in het Nederlandse rechten systeem. als je al in hoger beroep bent geweest kan je hierna nog naar een hoge raad gaan dit noem je een cassatie. de uitspraak hiervan noem je een arrest.


# Referenties 