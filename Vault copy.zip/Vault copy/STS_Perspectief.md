2025-02-11 10:55

Tags:  #Wetenschap #ICT #algemeen 

# STS_Perspectief

STS of de Science, Technology and Society studies (STS) gaat over hoe cultuur, politiek en de samenleving een effect heeft op Technologie innovatie en onderzoek en wat voor effect Technologie heeft op de Wetenschap, cultuur en politiek.

![[Pasted image 20250211110102.png]]

Het heeft allemaal effect en invloed op elkaar.

# Referenties 