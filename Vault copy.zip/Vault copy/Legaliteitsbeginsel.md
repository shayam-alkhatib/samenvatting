2025-03-13 14:38

Tags: #algemeen #rechten 

# Legaliteitsbeginsel

als een feit of daad gepleegd is voordat het strafbaar was dan kan je er niet voor vervolgd worden.





# Referenties 