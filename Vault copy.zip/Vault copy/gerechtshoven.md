2025-03-13 14:21

Tags: #algemeen #rechten 

# gerechtshoven

een gerechtshoven is een locatie waar een persoon heen gaat wanneer die gene in hoger beroep gaan.  er zijn 4 gerechtshovens in nederland en elk gaat over een van de [[ressorten]]. de uitspraak van een gerechtshoven noem je een arrest.




# Referenties 