2025-03-21 13:41

Tags: 

# Rationale getallen

Rationale getallen bevatten alle gehele getallen Z en maken deel uit van reële getallen R

het zijn eigenlijk gewoon breuken dsu 1/4 of 2/6 etc.




# Referenties 