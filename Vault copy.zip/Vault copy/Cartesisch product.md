2025-03-23 19:15

Tags: #Data #wiskunde 

# Cartesisch product

een cartesisch product zijn alle mogeljke tupels van twee verzamelingen




# Referenties 