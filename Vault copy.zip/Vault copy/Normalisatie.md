2025-02-27 12:05

Tags: #Data #Statistics #ICT 

# Normalisatie

Normalisatie gaat over het reduceren van Redundantie (herhaling) in data. dit wordt gedaan voor de volgende redenen.

1. Redundantie verlagen. (het zelfde stuk data wordt niet op meerdere plekken opgeslagen)
2. Data integriteit te waarborgen. (de data blijft meer consistent en is meer betrouwbaar. stel je voor je zou data hebben dat fout opgeslagen wordt, dit zou niet betrouwbaar zijn als je informatie ervan zou willen opdoen.)
3. Flexibiliteit te vergroten. (het is makkelijker om de database aan te passen of te vergroten als alles goed is genormaliseerd.)
4. Efficiëntie verbeteren. (data wordt sneller en gemakkelijker opgehaald.)

Dit wordt gedaan door de [[Normaalvormen]] click erop om verder uitleg hierover te krijgen.




# Referenties 