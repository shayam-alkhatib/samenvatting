2025-03-13 14:04

Tags: #rechten 

# Smaad

Smaad is als je iemand opzettelijk beledigd voor een karakteristiek die hij of zij heeft om hun goede naam of reputatie mee te beschadigen. dit is een strafbaar feit dat je 6 maanden in gevangenis kan laten belanden of een geld boete opgekregen kunt krijgen van de 3e cat. 

maximaal 11.000 euro dus




# Referenties 