2025-02-26 13:24

Tags: #Politiek 

# Jurisprudentie

jurisprudentie zijn de uitspraken van rechters op het wet. dus als er bijvoorbeeld een onduidelijk wet is die interpreteerbaar is dan is de uitspraak van een rechter op een rechtszaak een jurisprudent. dit zie je vaak terugkomen in privacy wetgeving of interpretatie van de wet als het komt op reeële gebeurtenissen.



# Referenties 