2025-02-20 11:59

Tags: #philosophy 

# Normen

Normen komen van ethische [[Waarden]] die een persoon kan hebben. normen zijn dan ook vaak gedrag regels als "je mag niet stelen" of "je mag niet iemand vermoorden".




# Referenties 