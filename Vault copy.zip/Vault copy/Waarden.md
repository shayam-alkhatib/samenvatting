2025-02-20 11:14

Tags: #philosophy 

# Waarden

waarden moet je zien als ethische statements of ideeën die je belangrijk vind.




# Referenties 