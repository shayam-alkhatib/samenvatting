2025-03-21 13:37

Tags: #wiskunde #Data 

# Gehele getallen

Gehele getallen of Z zijn alle gehele getallen onder en boven de 0 dus.

**Verzameling N** = opsommen: 0, 1, 2, 3, ...

**Verzameling Z** = ..., -3, -2, -1, 0, 1, 2, 3, ..




# Referenties 