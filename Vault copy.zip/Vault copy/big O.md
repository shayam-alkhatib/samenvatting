2025-03-25 14:17

Tags: #Data 

# big O

de big O notatie is de notatie van hoe lang iets duurt voordat de functie klaar is 




# Referenties 