2025-03-13 14:58

Tags: #rechten #Security 

# Defacen

defacen is het veranderen van een online webpagina terwijl je daar geen toestemming voor hebt. dit kan voor veel redenen gebeuren bijvoorbeeld politieke doeleinde of misschien doe je het extra om een bedrijf in de problemen te laten komen.




# Referenties 