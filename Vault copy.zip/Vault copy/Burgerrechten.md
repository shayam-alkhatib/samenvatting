2025-02-26 12:21

Tags: #Politiek #wet 

# Burgerrechten

Rechten die door een nationale en internationale overheden gegarandeerd zijn en die de burgers van een bepaald land of gebied zekerheid geeft in hun rechten. (garantie geeft)

burger rechten voorbeelden zijn: 
1. Vrijheid van meningsuiting
2. Vrijheid van religie
3. Het recht op [[Privacy]]
etc etc.





# Referenties 