2025-03-27 14:42

Tags: #Data 

# Lineaire Datastructuren

**Lineaire datastructuren** zijn datastructuren waarbij de elementen in een specifieke volgorde staan, en elk element precies één voorganger en één opvolger heeft (behalve het eerste en laatste element). Ze worden gebruikt om data sequentieel op te slaan en te verwerken.




# Referenties 