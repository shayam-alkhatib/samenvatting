2025-03-21 13:46

Tags: #Data #wiskunde 

# Complexe getallen

🔹 **Definitie:**  
Een **complex getal** is een getal dat bestaat uit een **reëel deel** en een **imaginaire deel**. Je schrijft het meestal als:

z = a + bi

waarbij:

a = reëel deel
b = coëfficiënt van het imaginaire deel
i = imaginaire eenheid

🔹 **Belangrijk om te weten:**

- Reële getallen zijn gewoon complexe getallen waarbij het complex is geschreven dus 5 is een Reële getal maar kan ook geschreven worden als 5 = 5 + 0i om het complex te maken
- Complexe getallen worden vaak gebruikt in techniek, elektronica en wiskunde om dingen te beschrijven die met gewone getallen niet kunnen.




# Referenties 