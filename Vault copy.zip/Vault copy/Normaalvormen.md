2025-02-27 12:18

Tags: #ICT #Data #Analytics 

# Normaalvormen

de Normaalvormen zijn de stappen dat je moet nemen o meen stuk tekst te normaliseren en het in een [[LGS]] of [[ERD]] type diagram weerleggen. 


Dit zijn de normaalvorm stappen:

0NV:
1. bepaal naam begin-ENTITEIT
2. Neem alle gegevens van een formulier over
3. verwijder alle proces gegevens
4. bepaal de primary key van de begin-ENTITEIT

1NV:
1. Verwijder alle herhalende groepen.
	1. Maak een nieuwe ENTITEIT type aan
	2. bepaal een unieke naam
	3. kopieer primary key attributen van de moeder ENTITEIT
	4. bepaal de uniek primary key voor de nieuwe ENTITEIT
2. Herhaal de bovenstaande stappen tot er geen Herhalende groepen meer zijn

2NV:
1. Verwijder alle attributen die slechts functioneel afhankelijk zijn van een deel van de sleutel.
	1. Maak een nieuw entiteittype aan met unieke naam
	2. Kopieer het afhankelijke deel van de sleutel
	3. verplaats alle afhankelijke velden
	4. bepaal unieke primarykey voor nieuw entiteittype
2. Herhaal bovenstaande stappen totdat geen functionele afhankelijkheid meer te vinden is


3NV:
1. Verwijder alle attribuuttypen die slechts functioneel afhankelijk zijn van een ander attribuuttype (niet sleutelveld)
	1. Maak nieuwe ENTITEITtype aan
	2. Kopieer afhankelijke attribuuttype
	3. Verplaats het afhankelijke veld(en)
	4. Bepaal primarykey nieuw entiteittype
2. Herhaal totdat geen functionele afhankelijkheid meer te vinden is
Alleen van toepassing op attribuuttypen die niet tot sleutel behoren!!







# Referenties 