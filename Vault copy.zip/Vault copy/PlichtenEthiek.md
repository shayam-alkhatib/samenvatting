2025-02-20 12:49

Tags: #philosophy 

# PlichtenEthiek

vaak ook [[Deontology]] genoemd is een ethische stroming waarbij morele principes en plichten centraal staan. Met een nadruk op absolute gedragsregels. Deze benadrukking is gebaseerd op universele principes, ongeacht de uitkomst van een actie.

dit is het tegenovergestelde van [[Gevolgenethiek]] of ook [[consequentialism]] genoemd. Gevolgenethiek benadrukt juist dat de uitkomsten van een actie de Belangrijkste ethische overweging is.




# Referenties 