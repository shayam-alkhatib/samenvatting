2025-02-10 21:51

Tags: #algemeen #philosophy 

# Utopie 


Een Utopie wordt beschreven als een een ideale "Near perfect" wereld of scenario waarin men zich in de toekomst kan beleven. 



# Referenties 