2025-03-21 13:34

Tags: #Data #wiskunde 

# Natuurlijke getallen

natuurlijke getallen beschreven als N is een universum van getallen. waarbij all gehele getallen behoren boven de 0 en ook inclusief de 0.




# Referenties 