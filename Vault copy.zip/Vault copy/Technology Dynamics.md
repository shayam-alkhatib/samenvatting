2025-02-11 11:04

Tags: #ICT #Studie #Wetenschap 

# Technology Dynamics


Techonolgy Dynamics is een studie dat de verandering in Technologie bestudeert. het kijkt naar internal en external veranderingen. internal zijn vaak problemen die worden opgelost door technologie en external is verandering in de samenleving dat zorgt voor technologische verandering.

in de samenleving zijn er allemaal verschillende invloeden en al die invloeden maken de toekomst daar wordt in principe naar gekeken.



# Referenties 