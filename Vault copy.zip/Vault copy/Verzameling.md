2025-03-21 13:27

Tags: #wiskunde 

# Verzameling

Een verzameling in wiskundige termen is een 'collectie' of 'groep' van 'dingen'. En van elk 'ding' kunnen we kijken of hij wel of niet behoort tot de verzameling. belangrijk is dat een 'ding' niet meerdere keren in de zelfde verzameling zitten. hierbij geldt Volgorde geen rol in een verzameling. 

een verzameling wordt aanduid door een hoofdletter en elementen door een kleine letter.

bijvoorbeeld: A={3,1,0,2}

hier staat dat verzameling A dingen 3,1,0 en 2 bevat. de volgorde maakt niet uit dus

A={3,1,0,2} = A={1,3,0,2}

dit is dus dezelfde verzameling.

![[Pasted image 20250321133142.png]]

dit is een beschrijving van de eigenschappen van verzameling A. hierbij zie je dat de 'dingen' van A behoren tot de [[Natuurlijke getallen]]. dit noemen wij de universum.


# Referenties 