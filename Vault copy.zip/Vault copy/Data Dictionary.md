2025-02-27 12:47

Tags: #Data 

# Data Dictionary

Een data dictionary of DD wordt gebruikt om je data uit te leggen in een legenda. De DD bestaat uit 3 tabellen wat hier wordt uitgelegd:
–Vastleggen betekenis entiteittypes 
= 
Wat is de definitie van elk entitiet?
In Alfabetische volgorde zetten in je legenda
–vastleggen betekenis attribuuttypes 
=
Wat is de betekenis van de attribuut?
Ook in alfabetische volgorde
Bij welk Entiteit behoord de attribuut en wat is de type data , en de waarden die het heeft
–vastleggen constraints/integriteitsregel
=
Welke entiteit zich aan welke constraints of regels moet houden. 
En hoe dit wordt geimplimenteerd (Implementatie hoe?)











# Referenties 