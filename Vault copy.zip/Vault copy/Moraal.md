2025-02-20 11:14

Tags: #philosophy 

# Moraal

moraal is je ethische perspectief. Je moraal bestaat uit je [[Waarden]] en [[Normen]].







# Referenties 