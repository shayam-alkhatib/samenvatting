2025-02-20 12:00

Tags: #philosophy 

# Deugden

deugend of het engelse benaming "virtue" betekent een 'goede' kwaliteit dat een persoon kan hebben deze kwaliteit wordt dan ook meestal etisch goed gezien.




# Referenties 