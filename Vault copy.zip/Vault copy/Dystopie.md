2025-02-10 21:48

Tags: #algemeen #Security 

# Dystopie


een Dystopie is het tegenovergestelde van een [[Utopie]]. het betekent eigenlijk "the worst case scenario". vaak wordt het gebruikt door mensen die een hele slechte toekomst voorspellen na hun mening



# Referenties 