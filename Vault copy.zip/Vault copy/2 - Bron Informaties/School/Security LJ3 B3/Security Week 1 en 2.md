Dit zijn de leerdoelen van week 1:

1. Inzicht krijgen in wat privacy is
2. Inzicht krijgen in de moeilijkheid en relativiteit van het onderwerp privacy
3. Inzicht krijgen in de mogelijke risico’s in het kader van privacy

Erin wordt uitgelegd wat de betekenis van Privacy is.

"De afscherming van beïnvloeding wordt ook omschreven als het Recht om met rust gelaten te worden."

Informatie is privé, voor een persoon of groep, als het ongewenst is als deze informatie buiten de persoon of groep gedeeld wordt.


Schade kan komen in de vormen van Materieel, immaterieel of Lichamelijk.


privacy moet beschermd worden voor: 

1. Ongewenste toegang tot confidentiële informatie
2. Ongewenst delen van confidentiële informatie
3. Ongewenst gebruik van gedeelde informatie
4. Gegevens verzamelen en gebruiken  
5. zonder gegeven goedkeuring


overbodige informatie neem week 1 HC door niks dat hier echt in moet



Dit zijn de leerdoelen van week 2:

1. Overzicht krijgen in regelgeving met betrekking tot privacy
2. Overzicht krijgen in de manieren waarop je privacy kunt beschermen


Je hebt in Nederland privacy wetten waar je aan moet houden. De meest bekende wet in dit gebied is de [[AVG (Algemene Verordening Gegevensbescherming)]] wet. 

naast de [[AVG (Algemene Verordening Gegevensbescherming)]] zijn er veel meer wetten voor privacy. zoals artikel 8 uit het Europese verdrag of het Dataprotectieverdrag van de Raad van Europa.