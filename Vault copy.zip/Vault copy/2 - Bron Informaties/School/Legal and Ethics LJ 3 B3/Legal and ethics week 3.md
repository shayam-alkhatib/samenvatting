	ik was er deze week niet bij de hoor les maar dit zijn de leerdoelen als volgt.

1. De student kent de definitie. functies en kenmerken van recht(regels)
2. De student kent de [[Burgerrechten]] (Civil liberties) en kan deze plaatsen in de rangorde van rechten
3. De student kent enkele Grondrechten uit de Nederlandse wet
4. De student kent de bronnen en hiërarchie van de verschillende soorten recht en rechtspraak
5. De student is in staat een uitspraak te over een casus op basis van de wetbronnen.
6. e student kent de soorten vonnissen en gevolgen daarvan.
7. De student kent de rol van het openbaar ministerie in de rechtspraak en de functionele rollen binnen het OM
8. De student kent de verschillen tussen computer assisted en targeted crime.
9. De student kent (de historie van) de Wet op de computercriminaliteit III
10. De student kan alle in deze OE geleerde Grondrechten en wetten toepassen in een (praktijk)casus

uit de powerpoint wordt aangegeven dat Recht een term is voor alle rechts regels die er bestaan. Rechten bestaan voor twee redenen

1. Ordenen van menselijk gedrag
2. Geschilbeslechting (dit betekent het oplossen van conflicten (dit noem je juridisch geschil) van twee of meer partijen door middel van de rechten die hem geboden of verboden zijn )

Rechtregels zijn normen die wij belangrijk vinden voor de samenleving. hier zijn de kenmerken.

1. opgesteld en gehandhaafd door overheid
2. gelden in beginsel voor iedereen
3. gaan in het algemeen voor andere regels en normen

dan heb je ook Rechtbronnen. Dit zijn de bronnen voor de rechten. Dus het antwoord op waar vind ik recht?

dit zijn de verschillende soorten Rechtbronnen:
1.Verdrag (Tractaat)
2.Wet
3.[[Jurisprudentie]]
4.Gewoonte- en ongeschreven recht (want normaal is in de samenleving)

en hier is het Hiërarchie van de wetten in Nederland:
1.Verdrag (Tractaat)
2.Grondwet
3.Wet in formele zin
4.Algemene Maatregel van Bestuur (AMvB, raamwet)
5.Ministeriele regeling


verder werdt uitgelegd hoe problemen tot wetten tot stand komen. eerst heb je natuurlijk een maatschappelijk probleem nodig. dit kan zijn dat burgers uitspreken dat ze mee milieu vriendelijke producten willen. hiervan wordt een Wets ontwerp gemaakt door ambtenaren of tweede kamer leden. hierna gaat dit naar [[Advies Raad van Staten]]. 


als je het over het wet hebt heb je formele wet en matrieel wet.

Formele zin:

•Procesrecht (regels die aangeven hoe proces moet worden gevoerd)

•In stand gekomen door samenwerking Parlement


Materiële zin:

•Rechtsregels die rechten geven of verplichtingen opleggen

•In stand gekomen door bevoegd orgaan (bv. APV, AMvB)



de mensen die wetten tot stand zetten zijn. 
1. [[Parlement]]
2. [[Regering]]
3. Gemeentes provincies etc

je kan op meerdere manieren iemand beledigen dit zijn de strafbare feiten ervan.

[[Smaad]] en [[Lasteren]] zijn de twee termen om iemand mee aan te klagen als hij of zij jou beledigd.  


in Nederland heb je ook het [[Rechterlijke organisatie]].


in cyber crime heb je twee soorten CRIME.

je hebt Computer assisted crime en Computer targeted crime.

assisted betekent dat je de computer gebruikt om een persoon aan te vallen. en targeted is een anval op een computer denk dan aan DDOS of een virus. je moet altijd denken wie de slachtoffer is als dat een computer is dan is het targeted. anders is het assisted.

in nederland heb je ook het [[Legaliteitsbeginsel]]. wat een erg belangrijk deel is van de wetgeving.

verder werd ook uitgelegd wat [[Computercriminaliteit III]] is en waarom het zo belangrijk is. 

naast de computer criminaliteit kan je ook in de problemen komen voor computer sabotage. je moet denken aan fysieke vernieling van computers of het plaatsen van virussen. de straf dat dan hieraan gekoppeld is kan verschillen van sociale impact.

gegevens aftappen of opnemen wanneer dit niet mag kan je een geldboete opleveren van de 4e cat (20.000 euro) en tot 1 jaar cel straf. dit kan je bijvoorbeeld doen met cookies om surf gedraf op te nemen zonder toestemming van de gebruiker dan.

nu komen we tot een belangrijk begrip namelijk [[Computervredebreuk]]. soms ook wel computerinbraak of hacken genoemd. een voorbeeld van [[Computervredebreuk]] is bijvoorbeeld [[Defacen]]. wat vaak gedaan wordt op politieke of overheids pagina's om bepaalde meningen of standpunten te veranderen.
