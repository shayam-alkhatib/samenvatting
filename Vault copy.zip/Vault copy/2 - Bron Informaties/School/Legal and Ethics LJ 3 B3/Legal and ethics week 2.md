deze lesweek gaat over ethiek en ethische dilemma's hierbij komen de volgende leerdoelen terecht.

1. Je kent de Definitie van [[Ethiek]] 
2. je kent de 4 verschillende soorten ethieken en wat de gevolgen zijn van die ethieken op ethische dilemma's. ook moet je deze ethieken kunnen herkennen en omschrijven als een voorbeeld gegeven wordt.
3. ethische dilemma's omschrijven en onderbouwen volgens een stappenplan?
4. de essentie van ethiek ook in de ict sector omschrijven
5. je kent de begrippen [[Waarden]], [[Normen]] en [[Deugden]].
6. en je kan de bovenstaande begrippen allemaal toepassen.

Je hebt 4 soorten Ethiek dat besproken wordt tijdens deze lessen en deze ethieken zijn ook 4 belangrijk ethieken geweest in de westerse geschiedenis.

1. [[DeugdenEthiek]]
2. [[PlichtenEthiek]]
3. [[Gevolgenethiek]] 
4. [[ZorgEthiek]]


Alle 4 de ethieken moet je kennen en kunnen toepassen aan dilemma's

verder werd er besproken waarom ethiek belangrijk is. dit is omdat een samenleving niet kan bestaan zonder. En later in je werk veld je ethische keuzes moet gaan maken. als je wel of niet ergens aan wilt gaan werken vanwege ethische overwegingen.

Er is dan ook een Ethische roadmap voor ICT

eerst [[Technology Dynamics]] om te kijken wat de interne of externe ontwikkelingen zijn. 
Daarna pas jij je ethische beeld hierop om te kijken in stap 3 wat je ermee moet doen. dus welke rechten je zou moeten toepassen.

