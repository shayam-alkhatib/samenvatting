 
De sheets van week 1 beginnen over het verschil tussen [[Disruption]] en [[Techruption]].

als volgt kwamen de volgende begrippen aan bod en dit zijn ook alle dingen die een student moest leren door de sheets.

1. het verschil tussen een [[Utopie]] en een [[Dystopie]]
2. Uitleggen wat [[Technologische Determinism]] is
3. Wat de [[4e Industriële Revolutie]] is en wat het inhoud
4. Wat [[STS_Perspectief]] is en waar het mee te maken heeft.
5. Uitleg de field [[Technology Dynamics]] 
6. En het verschil tussen [[SCOT]] en [[ANT]]


panopticon


Legal and ethics week 1 Discussiecollege

SCOT/[[ANT]]

chris geeft aan om SCOT of [[ANT]] toe te passen op je stage.

Scot wordt uitgelegd in week 1 gehoorcollege

wat is [[ANT]] dan?

ant is hetzelfde als SCOT alleen wat een social groep kan zijn is bij ANT wat breeder dan SCOT

een object waarbij groepen van mensen anders zouden gedragen bij tijdens of met het object?


kekrade of heerle7y



















