
de quiz bestaat uit 5 topics


# rechten algemeen
welke van de onderstaande is geen rechtsrbon:?
AVMB TOT STAND LATEN KOMEN


[^1]welke van onderstaande is geen hoofd- of bijkomende straffen?

welke van de onderstaande is jurispudentie: rechtspraak. en nog iets lol



[^2]welke van de onderstaand is geen burgerrecht
antwoord: recht op particulier bedrijf


# ethiek

plichten etiek vraag

wat is moraal: geheel van normen en waarden dat weergeeft wat wij zien als goed en verantwoordelijk gedrag


# ict en recht

[^3]computervredebreuk zo iets komt altijd in terug CHECK

freeware free to use not free to abuse niet gratis

open source is niet gratis open source dat je vrij kan kijken naar de source ne kunt gebruiken.
# ip



# overig

argumentatie 
circle redenering wat het is etc

panopticon: een omgeving waar je constant mensen kunt monitoren gedrag wordt zo gemanupuleerd.

[^1]: ![[Pasted image 20250328094413.png]]

[^2]: ![[Pasted image 20250328100101.png]]

[^3]: ![[Pasted image 20250328102901.png]]
