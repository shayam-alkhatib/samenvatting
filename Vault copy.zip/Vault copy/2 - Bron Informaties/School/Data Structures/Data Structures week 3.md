
Bij orienteren week 3 worden verzamelingen, relaties en grafen besproken.

Eerste vraag dat je moet kunnen beantwoorden is "wat is een [[Verzameling]]?"

ook moet je de verschillende getalverzamelingen weten ook wel 'universums' genoemd waarin getallen of verzamelingen kunnen bestaan.

Bijzondere getalverzamelingen:  N, Z, Q, R, C

•N : [[Natuurlijke getallen]]

•Z : [[Gehele getallen]]

•Q : [[Rationale getallen]]

•R : [[Reële getallen]]

•C : [[Complexe getallen]]

U betekent dus de Universum van getallen


A ̅ : complement van A betekent alle elementen van U die geen element zijn van A.

![[Pasted image 20250321140649.png]]

en

![[Pasted image 20250321140748.png]]

∀ betekent voor alle of voor elke.
∃ betekent er bestaat of er is tenminste een
¬ betekent niet of negatief zelfde als compliment
**Kort gezegd:**

- ¬P betekent **"P is niet waar"**.
- Als P bijvoorbeeld betekent "Het regent", dan betekent ¬P **"Het regent niet"**.

⇔ (als en slechts als / equivalentie)
→ is een **logisch gevolg** of **implicatie**.
**"Als x in C zit, dan zit x ook in A."**

![[Pasted image 20250321141527.png]]

![[Pasted image 20250321141718.png]]

je hebt ook Disjunkte verzamelingen:

        à doorsnede is leeg
dus dan is V1 en V2 apart van elkaar zijn. 

![[Pasted image 20250321143026.png]]

![[Pasted image 20250321143129.png]]

logisch ook maar je hebt een cheat sheet hiervoor oefenen jong.


![[Pasted image 20250321143208.png]]

![[Pasted image 20250321143305.png]]

Dus een lege verzameling is niet gelijk aan een lege verzameling tussen {}

je hebt ook een machtsverzameling. een machts verzameling is de hoeveelheid deelverzamelingen van een verzameling. bvb

![[Pasted image 20250321235915.png]]

dit zijn dus alle mogelijke deelverzamelingen van A. zo kan je ook de kardinaliteit bepalen. de kardinaliteit van alle deelverzamelingen van A is gelijk an 2 tot de macht de kardinalitiet van A.


(Gewone) verzamelingen:

•volgorde van de elementen speelt geen rol !

•“dubbele” elementen zijn niet relevant !

Meervoudige verzameling / Bag / Multiset:

bij ieder element wordt bijgehouden hoe vaak het voorkomt: “multipliciteit”


[[Cartesisch product]] is alle mogelijke tupels op basis van de verzamelingen.