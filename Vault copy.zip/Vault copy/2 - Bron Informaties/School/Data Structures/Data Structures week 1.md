

in week 1 van Data Structures werd het [[Normalisatie]] process uitgelegd voor een [[ERD]] of [[LGS]]

Hierbij kwamen ook de [[Normaalvormen]] aan bod. Dit was een erg belangrijk onderwerp dat aanbod komt wanneer je een database ontwerpt. hierbij werd ook uitgelegd wat een [[Data Dictionary]] was.

belangrijk is dat je dit allemaal goed kan toepassen zodat je dit later ook kan gebruiken als je zelf een database moet ontwikkelen.


in verdiepen kan je hiermee oefenen.
