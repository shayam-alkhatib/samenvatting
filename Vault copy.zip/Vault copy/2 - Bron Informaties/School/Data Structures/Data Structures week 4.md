
Verzamelingen, Relaties, Grafen    Deel II
1.  Relaties tussen verzamelingen
2.  eigenschappen van Relaties
3.  Functies
4.  begrip Graaf
 Abstracte DataTypes (ADT’s)
5. ADT Dictionary : zoeken, toevoegen, verwijderen
6. ADT Queue : toevoegen, verwijderen van de langstwachtende
Implementaties van ADT’s
7. ADT Dictionary : list, array, gesorteerde array
8. ADT Queue : list, array
9. ADT Array : zoeken, toevoegen, verwijderen

en ook tijd complexiteit wordt besproken in deze week.


we beginnen met verzamelingen relaties en grafen.

een R: A -> B betekent een relatie van A naar verzameling B. logisch hoop ik ;)

Domein(R)   = { x∈A | er is een y∈B met xRy }
dit betekent x element van A er is een y element van b met een relatie tussen x en y

Bereik(R)   = { y∈B | er is een x∈A met xRy }

hetzelfde maar dan omgekeerrd

Codomein(R) = B


codomein is alle 'eindbestemmingen' van een relatie 

Stel:

- A={1,2,3}
    
- B={a,b,c,d}
    
- Relatie R={(1,a),(2,b)}

dan geldt:
Domein(R) = {1, 2}
Bereik(R) = {a, b}
Codomein(R) = B = {a, b, c, d} (ook al worden c en d niet "gebruikt")

R: A -> A dan noemen we R een relatie op A

![[Pasted image 20250325125733.png]]

dit betekent voor alle elementen x is er een relatie van x naar x

irreflexief is het omgekeerde hiervan.



![[Pasted image 20250325130026.png]]

symmetrisch betekent: alle elementen van x en y geld dat als x een relatie heeft met y dan heeft y ook een relatie met x.

antisymmetrisch is als x r y en y r x dan geld dat x gelijk moet zijn aan y dus 4,4 of 6,6 of 8,8 noem het maar op 

> [!LET OP] Title
> Contents antisymmetrisch geld allleen maar als x R y heeft EN y R x. dus als je bijvoorbeeld V = {1,2,3} | x < y  dan als je kijkt naar de machtverdeling hiervan heb je alleen maar (1,2) en (2,3) dit is AS want geen enkel x heeft een R met y en andersom ook dus is hij gelijk waar
 




![[Pasted image 20250325130537.png]]


![[Pasted image 20250325132128.png]]





-----


we gaan het nu hebben over verschillende soorten [[Abstract DataType (ADT)]]:




een voorbeeld van een ADT is misschien een "Zoeklijst" waarvan het enigste functie iets op te zoeken is.

we gaan eerst kijken hoe dit eruit ziet voor een array. het fijne aan een array is dat de zoektijd **Constant is** 

de best case is
$$
O(1)
$$

avarage case is
$$
O(n )
$$

en worst case is
$$
O(n)
$$



*dus hij gaat gewoon n hoeveelheid stappen langs in een array tot hij de gezochte element vindt.*

nu kijken wij naar de [[big O]] notatie van een gesorteerde array


bij een gesorteerde array pak je 
$$
\frac{1}{2} n
$$
en dit blijf je doen totdat je bij je gegeven nummer bent. dus je kijkt is het kleiner of groter dan dit. dus de zoek grote wordt een stap groter met elk verdubbeling. de big O notatie hiervoor is:
$$
O(\log (n))
$$

ook heb je grafen als een soort data type

Graaf  bestaat uit:
 Knopen (punten) 		Engels : Vertices
 Pijlen (lijnen, relaties)	Engels : Edges    Verbinding tussen twee knopen
 Ongericht  of Gericht


vaak gebruikt bij waterleidingen plattegrond en verschillende soorten andere projecten

Een boom is een soort gerichte graaf waarin een punt/knoop een ingraad heeft van 0. dat betekent dat 1 punt knoop geen vader knoop punt heeft, en dat is dan de wortel. en je hebt dan ook bladeren met uigraad 0 dus dat zijn knopen die geen kinderen hebben.


Dit noem je [[Boom structuur]]. Lees dit atomic note veer meer uitleg van wat je allemaal moet weten jong dikke duim.


![[Pasted image 20250326161052.png]]




![[Pasted image 20250326161334.png]]



dan heb je ook een zoekboom die ziet er zo uit


![[Pasted image 20250326163702.png]]



