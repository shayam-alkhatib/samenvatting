

dit zijn de leerdoelen van deze week:

•Begrip van Lineaire en niet-linieare datastructuren

•Begrip van Abstracte DataTypes (ADT's)



je hebt [[Lineaire Datastructuren]] 
1. Geïndiceerd ([[array]], [[list]], [[tuple]]) 
2. niet geïndiceerd (files, linked lists))

[[Niet-Linear Datastructuren]]

1. set  (inclusief relationele database)
2. struct/record
3. object
4. netwerk (graaf)
5. boom

en ook een [[Abstract Datastructuur]]

1. Stack
2. Queue
3. Dict (Dictionary)
4. PR (priority Queue)


als we eerst kijken naar lineaire datastructuren pakken wij als voorbeeld een [[Array]]. 
de kenmerken hiervan vind je in de array zelf leer dit voor de toets of als je benieuwd bent.


Dit is hoe een insert werkt voor een array:
![[Pasted image 20250327143041.png]]


als tweede Lineaire Datastructuur kijken wij naar een [[List]]. 

en als derde kijken wij naar een [[Tuple]].

deze [[Lineaire Datastructuren]] zijn allemaal Geïndiceerd. nu gaan we kijken naar niet geïndiceerd [[Lineaire Datastructuren]].

1. File

