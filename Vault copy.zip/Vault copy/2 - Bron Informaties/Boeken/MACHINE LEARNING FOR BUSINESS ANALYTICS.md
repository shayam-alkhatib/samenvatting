Concepts, Techniques, and Applications with JMP Pro® Second Edition 2023

2025-02-05 16:04

Tags: #MachineLearning #Data #ICT 

# MACHINE LEARNING FOR BUSINESS ANALYTICS



3 - wat is [[Business Analystics]]? hier wordt gesproken over wat business analytics wel niet betekent en er wordt een voorbeeld benoemd waar bij de Washington post een van de enigste websites zijn waar je vliegtuig advertenties ziet vanwege de hoeveelheid militaire mensen die hun pagina bezoeken. 



















# Referenties 