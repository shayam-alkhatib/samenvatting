2025-02-10 21:53

Tags:  #ICT #Security 

# Technologische Determinism

"Een [[Reductionistische theorie]] die veronderstelt dat technologische ontwikkelingen ook de sociale structuur en culturele waarden van de maatschappij bepaalt."

De theory stelt dat technologie de grootste invloed is op sociale structuur en Culturele normen en misschien ook waarden van een maatschappij. hierbij worden andere invloeden "gereduceerd"




# Referenties 