2025-02-27 12:25

Tags: #Data #algemeen 

# ERD

ERD staat voor Entity Relationship Diagram. Een ERD toont eigenlijk alle relaties tussen entiteiten in een database. dit is handig want dan krijg je een goed beeld van de structuur van een database en dit wordt ook vaak gemaakt om te kijken of de integriteit van de database wel klopt of dat er misschien niet beter koppel tabellen gemaakt kunnen worden of niet.

![[Pasted image 20250227123030.png]]

Dit is een voorbeeld van een simpele ERD.
# Referenties 