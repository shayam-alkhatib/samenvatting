2025-03-13 14:06

Tags: #rechten 

# Lasteren

lasteren is het opzettelijk beledigen van iemand over een onware feit. bijvoorbeeld hun reputatie te verpesten door te verspreiden dat iemand een pedofiel is of iets dergelijks. dit kan je een geld boete opleveren van de 2e cat (5500 euro) of gevangeis straf.




# Referenties 