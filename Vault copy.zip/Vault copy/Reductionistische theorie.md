2025-02-10 22:01

Tags: #Theorie #Theory

# Reductionistische theorie

Dit is een soort theorie die invloeden op complexe zaken en processen versimpelen tot een enkel 1 of paar oorzaken.




# Referenties 