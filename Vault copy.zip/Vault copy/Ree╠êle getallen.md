2025-03-21 13:43

Tags: #wiskunde #Data 

# Reële getallen

De verzameling van **reële** getallen bevat

- gehele getallen: …, –3, –2, –1, 0, +1, +2, +3, …
- rationele getallen, die geschreven kunnen worden als een breuk van gehele getallen
- irrationele getallen, zoals √2, π, _e_, enz.

Elk reëel getal kan in de **decimale** getalsnotatie worden geschreven, met cijfers (_decimalen_) achter de komma. Rationele getallen hebben een eindig aantal decimalen (bijv. 3/8 = 0,375) of repeterende decimalen (bijv. 5/14 = 0,3 571428 571428 5…).




# Referenties 