2025-02-20 13:13

Tags: #algemeen 

# Deontology

vaak ook [[PlichtenEthiek]] genoemd is een ethische stroming waar de normen (gedrag regels) het belangrijkste zijn ongeacht de uitkomst. Dus ook al leidt dit tot negatieve uitkomsten maakt dat niet uit.

dit is het tegenovergestelde van [[Consequentialism/Gevolgenethiek]]. Gevolgenethiek benadrukt juist dat de uitkomsten van een actie de Belangrijkste ethische overweging is.





# Referenties 