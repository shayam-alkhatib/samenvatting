2025-02-12 14:54

Tags:  #Analytics #ICT #Security 

# ANT


ANT is hetzelfde als SCOT kwa opbouw en hoe het eruit ziet. Alleen wat een social groep kan zijn is bij ANT wat breeder dan SCOT

een object(sociale groep) waarbij groepen van mensen anders zouden gedragen bij tijdens of met het object. BVB ramadan of kerst ochtendeten of avond eten

dit object is bij SCOT duidelijk als een groep van mensen alleen zoals je hoort is het bij ANT wat meer onduidelijk.




# Referenties 