2025-03-26 13:21

Tags: #algemeen #Data #wiskunde 

# Boom structuur

een boom structuur moet zich aan bepaalde voorwaarden houden om gezien te worden als een bomen structuur. een boom structuur is eigenlijk een graaf dat op een bepaalde manier is opgesteld. hier zijn de regels als volgt.

1. •Een boom is een gerichte graaf waarin precies één knoop ingraad 0 heeft en alle andere knopen ingraad 1 hebben

2. •De knoop met ingraad 0 heet de wortel (ingraad betekent heeft het een vader punt?)

3. •Knopen met uitgraad 0 heten bladeren (heeft het een kind punt?)

4. •Als er een pijl van a naar b gaat dan heet a de vader van b, en b een zoon van a

5. •Knoop met dezelfde ‘vader’ à “Sibling”  (Broer)

6. •Als de uitgraad van alle knopen hoogstens 2 is, spreken we van een binaire boom

er zijn verschillende manieren om een binaire boom in te richten. hier wordt 3 manieren besproken.

**[^1]Preorder**             
1. eerst de root,
2. linker subboom,
3. rechter subboom



**[^2]Inorder**               
1. eerst de linker subboom,
2. root,
3. rechter subboom


**[^3]Postorder**            
1. linker subboom, 
2. rechter subboom,
3. root

de formule om de index van je boomstructuur te vinden is
$$
2^h -1
$$
h is hoogte (diepte) van de boomstructuur.





# Referenties 

[^1]: ![[Pasted image 20250326133029.png]]

[^2]: ![[Pasted image 20250326133546.png]]

[^3]: ![[Pasted image 20250326133746.png]]
