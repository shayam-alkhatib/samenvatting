2025-03-25 13:49

Tags: #Data 

# Abstract DataType (ADT)

Het abstracte datatype is een speciaal soort datatype, waarvan het gedrag wordt bepaald door een reeks waarden en een reeks bewerkingen.

"Abstract" wordt hierbij gebruikt omdat we deze datatypes kunnen gebruiken, we kunnen verschillende bewerkingen uitvoeren. Maar hoe die bewerkingen werken, is volledig verborgen voor de gebruiker.





# Referenties 