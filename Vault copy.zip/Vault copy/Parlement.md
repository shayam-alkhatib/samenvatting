2025-02-26 13:15

Tags: #Politiek #Nederland 

# Parlement

het parlement bestaat uit de eerste en de tweede kamer. samen maken ze het wetgevende macht van Nederland naast de regering. dit wordt ook wel de Staten generaal of volksvertegenwoordiging genoemd.




# Referenties 