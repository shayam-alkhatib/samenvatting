2025-03-27 14:31

Tags: #algemeen #Data 

# List

Een [[Lineaire Datastructuren]] (structuur) die data opslaat. dit zijn de kenmerken van een list:

1. Rij gegevens die in een bepaalde volgorde worden opgeslagen.
2. Waar en hoe het wordt opgeslagen is niet relevant.
3. aantal elementen ligt niet vast (bij een [[Array]] wel bijvoorbeeld)
4. Gegevens hoeven niet altijd van hetzelfde data type te zijn (ligt aan de programmeer taal).
5. Index gebruik is hetzelfde als bij een [[Array]]



# Referenties 